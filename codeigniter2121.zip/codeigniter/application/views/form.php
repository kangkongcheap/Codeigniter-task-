<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Activity 2</title>
  <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      width: 350px;
      background-color: #fff;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .title {
      font-size: 24px;
      color: #333;
      margin-bottom: 20px;
      text-align: center;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      font-size: 16px;
      color: #555;
      margin-bottom: 5px;
      display: block;
    }

    input[type="text"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    .flex {
      display: flex;
      gap: 10px;
    }

    .submit {
      background-color: royalblue;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .submit:hover {
      background-color: #0056b3;
    }

    .message {
      font-size: 14px;
      color: #777;
      text-align: center;
    }
  </style>
</head>

<body>
  <div class="container">
    <p class="title">Register</p>
    <p class="message">Sign up now and get full access to our app.</p>
    <form action="register" method="POST">
      <div class="form-group">
        <label for="firstname">First Name:</label>
        <input type="text" name="name" required>
      </div>
      <div class="form-group">
        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" required>
      </div>
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" name="username" required>
      </div>
      <button class="submit"  name="register">Submit</button>
    </form>
  </div>
</body>

</html>

</head>
