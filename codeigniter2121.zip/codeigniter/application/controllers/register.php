<?php

class Register extends CI_Controller
{

  public function index()
  {

    $this->load->view('form');
  }
  
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Register_model');
  }

  public function insert()
  {
    $data = array(
      'name' => $this->input->post('name'),
      'lastname' => $this->input->post('lastname'),
      'username' => $this->input->post('username'),
    );
    $this->Register_model->insert_user($data);
    if ($this->db->affected_rows() > 0) {
      echo "Registration successful!";
    } else {
      echo "Failed to register.";
    }
  }
}